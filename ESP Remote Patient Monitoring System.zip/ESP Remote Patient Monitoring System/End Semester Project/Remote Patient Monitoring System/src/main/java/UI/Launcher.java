package UI;

public class Launcher {
    public static void main(String[] args) {
        // Add the required JavaFX modules
        System.setProperty("javafx.verbose", "true");
        
        // Launch the application
        LoginPage.main(args);
    }
}